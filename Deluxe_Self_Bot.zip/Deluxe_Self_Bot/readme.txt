- Thanks for Purchasing Deluxe Self bot x1 Official Version
- Run python main.py to start the bot
- Join the official server for future bugs fix/updates for this selfbot*
- TOS are in The AutoBuy
- Reselling is prohibited* 

* = No Support/Updates will be provided for if you bought this project from reseller or reselling this

## Install Guide
- Put Token,Prefix(leave empty for no prefix), UserID and Tokenpass(few cmds need password example, steal pfps etc) in **.env** file / secrets if replit

- Type python3 main.py to start the project

- Hosting to host this self bot is this link --> https://pylexnodes.net/
- GO here Click on free adter create a server on free Discord Bot hosting {Python]
- After upload files at there and you knwo wht to do.